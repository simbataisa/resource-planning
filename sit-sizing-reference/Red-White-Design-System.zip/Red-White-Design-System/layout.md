# Layout

- Build mobile first. The layout switches at `bp-md` (767px); `bp-sm`, `bp-lg` and `bp-xl` adjust columns and type.
- Page side margins are fluid, about 4.4% of the viewport width in the source.
- Sections stack with `space-64` between them on desktop and `space-48` on mobile. Alternate `surface` and `surface-muted` bands to separate them; do not draw rules between sections.
- Card grids use a `space-24` gutter: three columns on desktop, two on tablet, one on mobile.
- Inside components, use `space-8` and `space-12`; `space-16` and `space-24` for padding.
- Headlines step down on mobile: `display` drops to 40px/60px; `heading2` to `heading4` keep their sizes at weight 300.
- Order a page as Header, Hero, product Cards or List, supporting content (Stat, Table, Accordion), then Footer.
