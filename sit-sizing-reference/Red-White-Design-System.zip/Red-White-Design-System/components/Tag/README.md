A small static label that classifies a card, row or headline.

Provide one or two words. Tags are not interactive; use a Button or link for actions.

- **Neutral**: `secondary-light-grey-90` fill, `ink` text. The default.
- **Brand**: `red-dark` fill, `primary-white` text (7.9:1). Use for "new" or promoted items; `primary-red` is too light for 14px white text.
- **Gold**: `primary-gold` fill, `primary-black` text. Premium and priority contexts only.
- **Success**: `bg-button-added` fill, `color-button-added` text, with a check mark or word so the state does not rely on color.

All tags use 14px/21px at weight 600, `space-4` by `space-8` padding and `radius-sm`. Use at most two tags on one card.
