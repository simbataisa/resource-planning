A vertical list of the steps the assistant is working through, each with its status.

Provide the ordered steps, each with a title, an optional one-line detail and a status: done, active or waiting.

- **Done**: a 24px `primary-black` dot with a white check.
- **Active**: a `red-dark` dot with the step number, and a title ending in an ellipsis.
- **Waiting**: an outlined dot and a title in `ink-muted`.
- **Connector**: a 2px `secondary-light-grey-100` line. **Detail**: `subnote` in `ink-muted`.

Each status has its own symbol, so it never rests on color. Collapse the list to a single "Đã hoàn tất 4 bước" line once the answer is ready.
