Two or more related Buttons joined into one control.

Provide the buttons and a name for the group. All buttons in a group share one look and one size.

- **Joined**: outer corners keep `radius-md`, inner corners are square, and neighbors share a single 1px `primary-black` border.
- **Split button**: a primary Button with a narrow menu trigger, divided by a 1px `on-primary` rule.

Use it for sibling actions on the same object. For choosing one option from a set, use ToggleGroup. Do not join more than four buttons; move the rest into a DropdownMenu.
