A fixed-height region that scrolls its own content, with a slim scrollbar in the system's colors.

Provide the content and a maximum height. Give the region a name so screen readers can announce it.

- **Thumb**: `ink-muted`, 8px wide, fully rounded.
- **Track**: `secondary-light-grey-80`.
- **Container**: optional 1px `border` and `radius-md`.

The region is focusable so it can be scrolled from the keyboard. Avoid nesting scroll areas, and never hide the scrollbar: it is the only sign that more content exists.
