A 40px square button that carries only an icon, for compact controls such as close, previous and next.

Provide one outlined line icon at 20px with a 2px stroke, and an `aria-label` that names the action.

- **Outline** (default): `surface` fill, 1px `primary-black` border.
- **Primary**: `primary` fill with an `on-primary` icon; `primary-hover` on hover. The icon is a 3:1 mark, so `primary-red` passes here.
- **Ghost**: no border, for toolbars and dialog close buttons.
- **Disabled**: `cta-disabled` fill, `ink-muted` icon.

All use `radius-md` and the `focus-ring` outline. Keep at least `space-8` between adjacent icon buttons. If the action is not obvious from the icon, use a Button with a label.
