A collapsible record of one tool call: its name, status, input and result.

Provide the tool name, a status (running, done, failed or awaiting approval), the input and the output.

- **Container**: `surface`, 1px `border`, `radius-md`.
- **Header**: a tool icon, the name in the `code` style at weight 600, a status Tag and a chevron.
- **Sections**: "Đầu vào" and "Kết quả" labels in `table-header` and `ink-muted`, each over a `code` block on `surface-muted` with `radius-sm`.
- **Status**: success Tag with a check; failure Tag in `red-dark` with a cross; running shows a Spinner.

Closed by default in a conversation; people open it to check the details. Mask account numbers and personal data in inputs and results. Preview values are placeholders.
