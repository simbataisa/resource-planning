An inline message that reports information, success, a caution or an error.

Provide a one- or two-word title that names the status, and one sentence saying what happened and what to do next.

- **Info**: `primary-sky-grey` ground, `ink` text, black icon.
- **Success**: `bg-button-added` ground, `color-button-added` title and icon.
- **Caution**: `secondary-gold` ground, `ink` text, black icon.
- **Error**: `surface` ground with a 2px `red-dark` border, `red-dark` title and icon.

Every variant carries a word and an icon, so no status depends on color. Body text is `subnote` in `ink`; padding is `space-16`, corners `radius-md`. Red is kept to the error border and title so it is not confused with the red primary action. Place the alert directly above the content it refers to.
