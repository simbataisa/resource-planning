A single search input with a leading magnifier icon.

Provide a placeholder that says what can be searched and an `aria-label`, since there is no visible label.

It is 56px tall to sit level with a Button, with a 1px `ink-muted` border, `radius-md` and a 20px `ink` icon inset `space-16` from the left. Focus shows the `focus-ring` outline.

Place one per page, in the Header or at the top of a results list. Submit on Enter; do not add a separate red button beside it.
