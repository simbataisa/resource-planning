A plain data table for rates, fees and comparisons.

Provide a caption, column headers and rows; mark the first cell of each row as its header.

- **Header row**: `table-header` (12px/18px, weight 600, uppercase) in `ink-muted` on `surface-muted`, with a 1px `primary-black` rule beneath.
- **Cells**: `table-default` (14px/21px) in `ink`, `space-12` by `space-16` padding, 1px `border` rule between rows.
- **Numbers**: right-aligned with tabular figures.
- **Hover**: `secondary-light-grey-60` row ground.

No vertical rules and no zebra stripes. Do not color numbers red or green to show direction; add an arrow or a word. The values in the preview are placeholders. Below `bp-md`, let the table scroll sideways.
