A Table with tools around it: search, filters, sorting, row selection and paging.

Provide the columns (with which are sortable), the rows, the page size and any bulk actions.

- **Container**: `surface`, 1px `border`, `radius-md`.
- **Toolbar**: a compact search input, an outline filter Button and the selection count in `ink-muted`.
- **Header**: `table-header` on `surface-muted`; a sortable column is a button with a sort icon, and the sorted one is `ink`.
- **Rows**: `table-default`, 1px `border` rules; a selected row takes `secondary-light-grey-80`.
- **Status**: Tags with a word and a symbol. **Amounts**: right-aligned, tabular, signed with plus or minus.
- **Footer**: the range shown and previous and next IconButtons.

Sort and filter on the server for long lists. Do not color amounts red or green; the sign carries the meaning. Preview data is placeholder.
