A 24px box for turning one option on or off, or for picking several from a list.

Provide a label to the right of each box; the whole label is clickable.

- **Unchecked**: `surface` fill, 1px `ink-muted` border, `radius-sm`.
- **Checked**: `primary` fill with an `on-primary` check mark. The mark is a 3:1 graphic, so `primary-red` passes.
- **Disabled**: `secondary-light-grey-80` fill, `secondary-mid-grey-80` border, label in `ink-muted`.
- **Focus**: `focus-ring` outline around the box.

Stack options with `space-12` between them. Use Switch when the change applies immediately; use Radio when only one option may be chosen.
