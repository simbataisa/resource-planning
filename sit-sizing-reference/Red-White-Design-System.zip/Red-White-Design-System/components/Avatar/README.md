A circle that stands for a person or account, showing a photo or initials.

Provide a name; a photo is optional. Without a photo, show up to two initials.

- **Sizes**: 32px, 40px (default) and 56px.
- **Initials**: weight 600 in `ink` on `primary-ivory`, or `primary-white` on `primary-black` for contrast in a group.
- **Status dot**: 12px, `color-button-added`, ringed in `surface`, with a text alternative.
- **Stack**: avatars overlap by `space-8` with a 2px `surface` ring; a neutral "+3" closes the row.

Always give the name as the accessible label. Do not use red for avatar fills.
