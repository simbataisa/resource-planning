A small key cap for showing keyboard keys and shortcuts in text.

Provide the key name, or several keys in the order they are pressed.

It uses the `mono` family at 12px/18px, on `surface` with a 1px `ink-muted` border, a 2px bottom edge and `radius-sm`. Join keys pressed together with a plus sign; show keys pressed in sequence side by side.

Use the names printed on the keys (Esc, Ctrl, Shift) and the platform's own symbols on Mac. Shortcuts are an extra; every action also needs a visible control.
