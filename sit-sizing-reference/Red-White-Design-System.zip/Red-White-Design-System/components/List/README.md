A vertical list of navigable rows, each with an icon tile, a title, a supporting line and a chevron.

Provide for each row an outlined line icon, a title of one to three words, an optional supporting line and a destination.

- **Row**: `space-16` padding, 1px `border` rule between rows; `surface-muted` on hover. The whole row is the link.
- **Icon tile**: 40px, `primary-ivory` fill, `radius-md`, 20px `primary-black` icon.
- **Title**: `contenttitle` in `ink`. **Supporting line**: `subnote` in `ink-muted`.
- **Chevron**: 20px in `red-dark`.

Use it for menus and product indexes on mobile; on desktop prefer Cards. The icons in the preview are simple placeholders; swap in the product's own icon set.
