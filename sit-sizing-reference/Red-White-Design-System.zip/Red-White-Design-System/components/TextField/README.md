A single-line text input with a label above and helper or error text below.

Provide a visible label, an optional placeholder and optional helper text. Always pair the input with its label; never use the placeholder as the label.

- **Default**: `surface` fill, 1px `ink-muted` border (6.2:1 on white), `radius-md`, `space-12` by `space-16` padding, text in `default`.
- **Focus**: 2px solid `primary-black` outline, offset 2px.
- **Error**: 2px `red-dark` border and a `red-dark` message that starts with a word ("Lỗi:"), so the state never relies on color alone.
- **Disabled**: `secondary-light-grey-80` fill, `secondary-mid-grey-80` border, `ink-muted` text.

Label and helper text use `subnote`; the label is semibold. Do not use `primary-red` for error text: it is below 4.5:1 on white.
