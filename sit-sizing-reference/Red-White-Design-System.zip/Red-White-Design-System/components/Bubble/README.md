A rounded container for one chat message.

Provide the text and who sent it. Incoming and outgoing messages sit on opposite sides.

- **Incoming**: `secondary-light-grey-80` ground, `ink` text, aligned to the start.
- **Outgoing**: `primary` ground, `on-primary` text (4.72:1), aligned to the end.
- **Shape**: `radius-md`, `space-12` by `space-16` padding, at most 80% of the thread width.
- **Meta**: `subheader` in `ink-muted` under the last bubble.

Sides, not color alone, tell the two speakers apart. Stack bubbles with `space-8` between them. For a message with a name and avatar, use Message.
