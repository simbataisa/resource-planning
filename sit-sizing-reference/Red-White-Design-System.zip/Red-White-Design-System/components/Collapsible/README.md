A single region that expands and collapses under a trigger, for detail most people do not need.

Provide the trigger label and the hidden content. The label says what will appear.

- **Trigger**: `contenttitle` in `red-dark` with a 16px chevron that turns when open.
- **Content**: `subnote` in a `surface` panel with 1px `border`, `radius-md` and `space-16` padding, `space-12` below the trigger.

It starts closed. Use it for one optional block; for a list of questions use Accordion. Never hide required steps, fees or conditions people must accept.
