A searchable palette of commands and destinations, opened with a keyboard shortcut.

Provide the list of commands, each with a label, optional icon and shortcut, sorted into named groups.

- **Panel**: `surface`, 1px `border`, `radius-md`, `shadow-float`, at most 480px wide.
- **Search row**: a borderless input with a 20px search icon and a 1px `border` rule beneath.
- **Group heading**: `table-header` in `ink-muted`.
- **Item**: `default`; the active item has a `secondary-light-grey-80` ground and weight 600.

Filter as the person types, keep the first match active, move with the arrow keys and run with Enter. Show a short "no results" line when nothing matches.
