Page numbers with previous and next arrows, for long lists such as news and search results.

Provide the current page, the total number of pages and a link for each visible page.

- **Page**: 40px target, `ink-muted` number; `ink` on hover.
- **Current**: `ink` at weight 600 with a 2px `primary` underline, the same marker as Tabs and the Header.
- **Arrows**: outlined 40px squares with `radius-md`, like IconButton. At the first or last page the arrow uses a `secondary-mid-grey-80` border and `ink-muted` icon.

Show the first, last and up to three pages around the current one; collapse the rest to an ellipsis. Below `bp-md`, show only the arrows and "1 / 12".
