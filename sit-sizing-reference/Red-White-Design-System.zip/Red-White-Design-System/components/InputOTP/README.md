A row of single-character boxes for entering a one-time code.

Provide the number of digits (four or six), a label and a line saying where the code was sent.

- **Box**: 48 by 56px, 1px `ink-muted` border, `radius-md`, digit at 24px and weight 600.
- **Gap**: `space-8`, with a short `ink-muted` dash splitting six digits into two groups of three.
- **Focus**: the `focus-ring` on the active box. **Error**: 2px `red-dark` borders and a worded message below.

Move focus forward as each digit is typed and back on delete, accept a pasted code in one go, and offer the numeric keyboard. Never mask the digits.
