The placeholder shown when a list, table or search has nothing to display.

Provide an icon, a title saying what is empty, one sentence on why or what to do, and at most one action.

- **Icon tile**: 56px, `primary-ivory`, `radius-md`, 20px outlined icon.
- **Title**: `heading3`. **Text**: `default` in `ink-muted`.
- **Action**: one primary Button, `space-16` below the text.

Center it in the space the content would fill. For a search with no matches, restate the query and offer to clear filters with an outline Button, since nothing is wrong and red is not needed.
