A dismissible window over a scrim for a short, focused task such as a small form.

Provide a title, optional description, the content and its actions. Keep it to one task and at most a handful of fields.

- **Scrim**: `overlay`. **Panel**: `surface`, `radius-md`, `shadow-float`, `space-24` padding, at most 440px wide.
- **Title**: `heading3` in `ink`. **Description**: `default` in `ink-muted`.
- **Close**: a ghost IconButton at the top right; Escape and a scrim click also close it.
- **Actions**: right-aligned, outline Button then one primary Button.

Trap focus inside while open and return it to the trigger on close. For confirmations that must not be dismissed by accident, use AlertDialog. Below `bp-md`, prefer Drawer.
