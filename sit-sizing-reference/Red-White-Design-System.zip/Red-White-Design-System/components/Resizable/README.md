Two or more panes separated by a handle the person can drag to change their sizes.

Provide the panes, a starting split and minimum sizes for each pane.

- **Container**: 1px `border`, `radius-md`.
- **Handle**: a 12px strip with 1px `border` rules and a grip icon in `ink-muted`; it shows the `focus-ring` on focus.
- **Secondary pane**: `surface-muted` ground.

The handle is keyboard operable: arrow keys move it in steps. Remember the person's split between visits. Below `bp-md`, stack the panes and remove the handle.
