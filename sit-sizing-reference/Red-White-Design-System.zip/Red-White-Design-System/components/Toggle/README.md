A button that stays pressed to show an option is on.

Provide an icon or short label, an accessible name and the pressed state.

- **Off**: `surface` fill, 1px `ink-muted` border, `ink` icon, `radius-md`, 40px square.
- **On**: `primary-black` fill with a `primary-white` icon. The fill inverts, so the state does not depend on hue.
- **Hover**: `secondary-light-grey-80`.

Use it for formatting and view options that take effect at once. For a setting with a label, use Switch. Red is not used here, so toggles never compete with the primary action.
