Primary site navigation whose items open wide panels of links.

Provide four to six top-level items; for each, a featured tile and up to six links with a title and a one-line description.

- **Bar**: `surface`, 56px tall, 1px `border` rule; items in `default`, `ink-muted` until open.
- **Open item**: `ink` at weight 600 with a 2px `primary` underline, the system's selected marker.
- **Panel**: `surface`, `shadow-float`, `space-24` padding, three columns with a `space-24` gutter.
- **Featured tile**: `primary-ivory`, `radius-md`, title in `heading3`.
- **Link**: title in `contenttitle`, description in `subnote` and `ink-muted`; `secondary-light-grey-80` on hover.

Open on click or Enter, not hover alone. Below `bp-md`, move the items into a Sheet with an Accordion.
