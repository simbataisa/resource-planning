A text link, inline in a sentence or standing alone as a light call to action.

Provide link text that says where it goes; avoid "bấm vào đây".

- **Inline**: `ink` text with an underline; `red-dark` on hover. The underline, not color, marks it as a link.
- **Standalone**: `red-dark` at weight 600 with a trailing arrow, underlined on hover. Use at the end of a card or section.
- **On dark**: `primary-white` underlined, on `primary-black` or `secondary-grey-100`. The focus ring switches to white.

Use a Button, not a link, for actions that change data. Do not set links in `primary-red` below 24px.
