A rotating ring that shows something is in progress when its length is unknown.

Provide a size and a status text, visible or as an accessible label.

- **Ring**: a `secondary-light-grey-100` track with a `primary` arc.
- **Sizes**: 16px inline, 24px default, 40px for a whole region.
- **In a Button**: a 16px white ring before the label, with the button disabled and the label changed to say what is happening.

Pair it with words for anything over a second or two. It slows when the person prefers reduced motion. When progress can be measured, use Progress; when content is loading, use Skeleton.
