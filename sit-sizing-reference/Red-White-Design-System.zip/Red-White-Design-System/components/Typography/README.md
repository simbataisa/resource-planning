The type styles applied to long-form content: headings, lead, body, lists, quotes, inline code and captions.

Provide structured content with one top heading and headings in order.

- **Eyebrow**: `wtypecaptionsmall` in `red-dark`.
- **Headings**: `heading1` and `heading2` at weight 300; `heading3` at weight 600.
- **Lead**: `highlight`. **Body**: `default`, or `contentbody` for long articles. **Caption**: `subnote` in `ink-muted`.
- **Link**: `ink`, underlined. **Inline code**: the `mono` family on `secondary-light-grey-80` with `radius-sm`.
- **Quote**: `subtitle` on a `primary-ivory` block with `radius-md`.

Keep lines to about 70 characters (640px), with `space-12` between blocks. Text is `ink` on `surface`; red appears only in the eyebrow.
