A preview card that appears when the pointer rests on a link, showing a little more about its target.

Provide the link and a compact summary: an avatar or icon, a title and one or two lines.

- **Card**: `surface`, 1px `border`, `radius-md`, `shadow-float`, `space-16` padding, 300px wide.
- **Title**: `contenttitle`. **Text**: `subnote` in `ink-muted`.

Show it after a short delay on hover and on keyboard focus. It is a preview only: nothing in it should be required reading or the only route to an action, because touch screens never show it.
