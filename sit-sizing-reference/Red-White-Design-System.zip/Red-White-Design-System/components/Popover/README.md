A small floating panel anchored to its trigger, for a few related controls or details.

Provide a trigger and the panel content. Keep the content to a short heading and one to three controls.

- **Panel**: `surface`, 1px `border`, `radius-md`, `shadow-float`, `space-16` padding, 280px wide, offset `space-8` from the trigger.
- **Heading**: `contenttitle`. **Supporting text**: `subnote` in `ink-muted`.

Open on click, not hover. Close on Escape, an outside click or when focus leaves. For plain explanatory text use Tooltip; for a list of actions use DropdownMenu.
