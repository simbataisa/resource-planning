A small dark label that explains a term or control on hover or focus.

Provide one short sentence, and attach it to a focusable trigger with `aria-describedby`.

It uses a `secondary-grey-100` ground with `primary-white` text in `subnote`, `space-8` by `space-12` padding, `radius-sm`, `shadow-pop` and a 6px arrow pointing at the trigger. Maximum width is 240px.

Show it on both hover and keyboard focus, and hide it on Escape. Never put links, buttons or essential instructions in a tooltip; anything a person must read belongs on the page.
