A draggable control for choosing a number within a range, where a rough value is enough.

Provide a label, the minimum, maximum, step and current value, and show the value in words beside the label.

- **Track**: the filled part and the thumb are `primary`; the rest is a neutral grey.
- **Readout**: `subnote` at weight 600, updated as the thumb moves.
- **Range labels**: `subnote` in `ink-muted` at either end.

Arrow keys change the value by one step. When the exact figure matters, pair the slider with a TextField that holds the same value.
