The white top bar: name, primary navigation and the one red login action.

Provide the name in plain type (no logo is included), three to six navigation links and one action. Mark the current page with `aria-current="page"`.

- **Bar**: `surface` fill, 56px tall, 1px `border` rule beneath.
- **Links**: `default` in `ink-muted`; `ink` on hover. The current page is `ink` at weight 600 with a 2px `primary` underline.
- **Action**: a flush, full-height `primary` block with an `on-primary` label in `contenttitle`, square corners, `primary-hover` on hover. This is the only red fill in the bar.
- **Focus**: 2px solid `primary-black` outline, inset.

Below `bp-md`, collapse the links into a menu and keep the name and the action visible. Do not add a second filled action to the bar.
