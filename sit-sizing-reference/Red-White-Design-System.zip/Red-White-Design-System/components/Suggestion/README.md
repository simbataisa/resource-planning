A row of tappable prompts that start or continue a conversation.

Provide two to five short questions or commands, written as the person would say them.

- **Chip**: `subnote` in `ink` on `surface`, a 1px `ink-muted` border, fully rounded (half its height), `space-8` by `space-16` padding.
- **Hover**: `secondary-light-grey-80` ground and a `primary-black` border.
- **Row**: chips wrap, `space-8` apart.

Tapping a chip sends it as a message. Show them on an empty conversation and after an answer, and remove them once one is used. Keep each to one line.
