One entry in a conversation: avatar, sender name, time and the message body.

Provide the sender, the time and the content, which may be text in a Bubble, an Attachment or other components.

- **Layout**: a 40px Avatar and the content, `space-12` apart; the person's own messages mirror to the end side.
- **Header**: name in `contenttitle`, time in `subheader` and `ink-muted`.
- **Body**: a Bubble, `space-4` below the header.

Stack messages with `space-16` between them, and group consecutive messages from one sender under a single header. The assistant's avatar uses `primary-black`; red is kept for the person's own bubbles.
