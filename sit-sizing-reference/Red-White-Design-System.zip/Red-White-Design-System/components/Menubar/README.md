A horizontal bar of menus, as in a desktop application.

Provide three to six top-level labels, each opening a menu of actions with optional shortcuts.

- **Bar**: `surface`, 1px `border`, `radius-md`, `space-4` padding.
- **Top-level item**: `default`, `radius-sm`; when open it takes a `secondary-light-grey-80` ground and weight 600.
- **Menus**: as DropdownMenu.

Left and right arrows move between menus, up and down within one. Use it only in dense, tool-like screens; for site navigation use the Header or NavigationMenu.
