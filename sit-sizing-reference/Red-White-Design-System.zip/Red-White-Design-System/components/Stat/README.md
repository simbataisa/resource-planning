A big figure with a one-line label, for rates, fees and other headline numbers.

Provide the figure, formatted for Vietnamese readers (comma as the decimal mark), and a label of a few words.

- **Figure**: `stats` (40px/60px, weight 600) in `primary-red`. At this size red on white passes as large text (4.39:1 against a 3:1 floor).
- **Label**: `subnote` in `ink-muted`.
- **Rule**: 2px `primary-black` line above, with `space-12` beneath it.

Show two to four stats in a row with `space-32` between them. The figures here are placeholders; never publish a rate without its source and date.
