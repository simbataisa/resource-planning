A list of messages or jobs waiting their turn while the assistant is busy.

Provide the queued items in order and a way to remove each one.

- **Container**: `surface`, 1px `border`, `radius-md`, `space-16` padding.
- **Header**: "Hàng chờ" in `contenttitle` with the count in `subnote` and `ink-muted`.
- **Row**: position number in `ink-muted`, the text on one line with an ellipsis, and a ghost IconButton to remove it; 1px `border` rules between rows.

Show it above the PromptInput only while something is queued. Items run in order; let people remove but not silently reorder them.
