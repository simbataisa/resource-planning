A dark panel for showing code, with a file name and a copy action.

Provide the code, its language or file name, and whether to show the copy button.

- **Panel**: `secondary-grey-100` ground, `radius-md`, text in `primary-white`.
- **Text**: the `code` style in the `mono` family, 14px/21px.
- **Header**: file name at the left, "Sao chép" at the right, over a 1px `cta-secondary` rule.
- **Syntax**: keywords and strings in `secondary-gold`, comments in `secondary-mid-grey-80`. Both clear 4.5:1 on the dark ground.

Long lines scroll sideways; do not wrap code. The focus ring is white on this ground. For a word or two of code inside a sentence, use the inline style shown in Typography.
