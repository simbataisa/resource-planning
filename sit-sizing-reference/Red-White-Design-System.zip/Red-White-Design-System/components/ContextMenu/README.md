A menu of actions that opens at the pointer on right-click or long press.

Provide the target region and three to six actions that apply to it.

It looks and behaves like DropdownMenu: `surface` panel, 1px `border`, `radius-md`, `shadow-float`, items in `default` with a `secondary-light-grey-80` hover ground and shortcuts in `ink-muted`.

Every action in a context menu must also be reachable another way, such as a visible button or a DropdownMenu, because the gesture is hidden and unavailable to many people.
