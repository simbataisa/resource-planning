The message composer for an assistant: a growing text area with a toolbar and a send button.

Provide a placeholder that says what can be asked, the available tools (attach, search and so on) and the send handler.

- **Container**: `surface`, 1px `ink-muted` border, `radius-md`, `space-12` padding; the `focus-ring` wraps the whole box.
- **Text area**: borderless, `default`, growing from two lines to about eight before it scrolls.
- **Toolbar**: ghost IconButtons and small ghost Buttons at the left, a hint in `subheader` and `ink-muted`, then a `primary` send IconButton at the right.

Enter sends and Shift+Enter adds a line. While a reply is streaming, the send button becomes a stop button. Disable send when the box is empty.
