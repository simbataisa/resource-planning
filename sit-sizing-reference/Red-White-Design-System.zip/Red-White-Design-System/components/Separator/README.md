A thin rule that divides content, horizontally or vertically.

Provide the orientation and, optionally, a short label that sits in the middle of a horizontal rule.

It is a `border-thin` line in `border`. A label uses `subnote` in `ink-muted` with `space-12` either side. Vertical separators stretch to the height of the row they sit in.

Use spacing first and a separator only when spacing alone does not group the content. Between page sections, alternate `surface` and `surface-muted` bands instead.
