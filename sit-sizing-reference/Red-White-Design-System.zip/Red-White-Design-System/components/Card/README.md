A white container for one product or topic: media, eyebrow, title, one line of text and a single link.

Provide an image (or a flat color block), a short eyebrow, a title, at most two lines of text and one link. Place cards on `surface-muted` or `surface`.

- **Outlined** (default): `surface` fill, 1px `border`, `radius-md`.
- **Raised**: no border, `shadow-card`. Use on `surface-muted` bands or for the featured card.

Padding is `space-24`; gaps inside are `space-8`. Eyebrow uses `wtypecaptionsmall` in `ink-muted`, the title `heading3` in `ink`, the text `default` in `ink-muted`, and the link `contenttitle` in `red-dark`.

Use one link per card, not a button. Do not mix outlined and raised cards in the same row except to feature one.
