A collapsible block that shows the assistant's thinking before its answer.

Provide the reasoning text and how long it took. It is closed by default once the answer arrives.

- **Trigger**: `subnote` in `ink-muted` with a clock icon, the duration and a chevron.
- **Body**: `subnote` in `ink-muted` on `surface-muted`, `radius-md`, `space-12` by `space-16` padding.
- **Answer**: follows in `default` and `ink`, `space-12` below.

While thinking is in progress, keep it open and show "Đang suy nghĩ…" with a Spinner. The muted treatment marks it as working notes, not the answer; never put the only statement of a fact in here.
