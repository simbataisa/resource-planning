A card for a helper agent that the main assistant has handed a piece of work to.

Provide the agent's name or role, who delegated the work, its status and its current steps.

- **Card**: `surface`, 1px `border`, `radius-md`, `space-16` padding.
- **Header**: a `primary-black` Avatar with a bot icon, the name in `contenttitle`, a line in `subnote` and `ink-muted`, and a status Tag.
- **Steps**: indented under a 2px `secondary-light-grey-100` rule, with the same status dots as Task.

Nesting shows that the work belongs to the parent conversation. When it finishes, collapse the steps and show a one-line result. Keep to one level of nesting on screen.
