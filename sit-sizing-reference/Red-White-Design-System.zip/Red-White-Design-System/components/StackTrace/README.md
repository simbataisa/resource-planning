A collapsible error report: the error type, its message and the call frames that led to it.

Provide the error name, the message and the frames, each with a function name and a file location.

- **Container**: `surface` with a 2px `red-dark` border and `radius-md`, as the error Alert.
- **Header**: "Lỗi:" and the error type at weight 600 in `red-dark`, then the message in the `code` style.
- **Frame**: function name in the `code` style at weight 600, location right-aligned in `ink-muted`.
- **Library frames**: all `ink-muted`, so the application's own frames stand out by weight.

Show the first few frames and collapse the rest. Offer a copy action for the whole trace. Never show a raw stack trace to customers; this is for internal and developer tools.
