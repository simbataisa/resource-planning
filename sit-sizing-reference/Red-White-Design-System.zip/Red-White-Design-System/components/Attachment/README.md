A compact card for one attached file, showing its name, type and size.

Provide the file name, type, size and, while uploading, the progress. Offer a remove action when the person can still change it.

- **Card**: `surface`, 1px `border`, `radius-md`.
- **Icon tile**: 40px, `primary-ivory`, `radius-sm`, with a 20px file icon.
- **Name**: `subnote` at weight 600. **Meta**: `subheader` in `ink-muted`.
- **Uploading**: a 4px `primary` bar with the percentage in words.
- **Remove**: a ghost IconButton named after the file.

Truncate long names in the middle so the extension stays visible. Show a failed upload with a worded error in `red-dark` and a retry action.
