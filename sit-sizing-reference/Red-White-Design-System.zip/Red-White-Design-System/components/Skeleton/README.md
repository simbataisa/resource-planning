Grey placeholder shapes that stand in for content while it loads.

Provide shapes that match the layout about to appear: a circle for an Avatar, bars for lines of text, a block for media.

- **Shape**: `secondary-light-grey-100`, `radius-sm`, or a full circle.
- **Motion**: a slow pulse, switched off when the person prefers reduced motion.
- **Spacing**: the same gaps as the real content, so nothing shifts when it arrives.

Mark the region as busy and give it a name such as "Đang tải". Use it for loads over about half a second; for shorter waits show nothing, and for actions in progress use Spinner.
