A summary of a test run with counts, a proportion bar and the individual results.

Provide the totals for passed, failed and skipped, the duration and the list of tests with their status.

- **Container**: `surface`, 1px `border`, `radius-md`.
- **Summary**: counts in `subnote` at weight 600, each with its symbol: a check in `color-button-added`, a cross in `red-dark`, a dash in `ink-muted`.
- **Bar**: 8px segments in `color-button-added`, `red-dark` and `secondary-mid-grey-80`.
- **Test row**: a 24px status dot with the same symbol, the name in the `code` style and the time in `subheader` and `ink-muted`.

Passed and failed are told apart by symbol and word as well as color, and the two colors differ in lightness. List failures first, and let a failed row open its StackTrace.
