A collapsible list of the documents and pages an answer drew on.

Provide the sources in the order they are cited, each with a title, where it comes from and a link.

- **Trigger**: `subnote` at weight 600 with a count, such as "Đã dùng 2 nguồn", and a chevron.
- **Row**: a `surface` panel with 1px `border` and `radius-md`; `secondary-light-grey-80` on hover.
- **Number**: a 24px `primary-black` square with `radius-sm`, matching the InlineCitation in the text.
- **Title**: `contenttitle`. **Origin**: `subnote` in `ink-muted`, with the date where known.

Place it directly under the answer. List only sources that were actually used, and show how current each one is.
