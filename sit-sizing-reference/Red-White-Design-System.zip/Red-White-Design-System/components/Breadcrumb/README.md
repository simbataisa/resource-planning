A one-line trail showing where the current page sits in the site.

Provide the ordered list of parent pages and the current page; the current page is text, not a link.

Text uses `subnote`. Parent links are `ink-muted` and turn `ink` with an underline on hover. Separators are a slash in `ink-muted` with `space-8` either side. The current page is `ink` at weight 600.

Place it directly under the Header on pages two or more levels deep. Below `bp-md`, show only the immediate parent.
