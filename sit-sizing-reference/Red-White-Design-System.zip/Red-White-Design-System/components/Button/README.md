The action control, in four looks: primary (red), outline, dark and disabled.

Provide a short verb-led label in sentence case. There is no component bundle yet: copy the markup and classes from the preview.

- **Primary**: `primary` fill, `on-primary` label, `primary-hover` on hover. One per view, for the main action.
- **Outline**: `surface` fill, 1px `primary-black` border, `ink` label. The default for secondary actions such as "Xem thêm".
- **Dark**: `primary-black` fill, `primary-white` label, `cta-secondary` on hover. Use on tinted panels where red would clash.
- **Disabled**: `cta-disabled` fill, `ink-muted` label.

All looks use the `contenttitle` style, `space-16` by `space-24` padding and `radius-md`, giving a 56px tall control.

Do not place two primary buttons side by side. Keep the label at 16px semibold.
