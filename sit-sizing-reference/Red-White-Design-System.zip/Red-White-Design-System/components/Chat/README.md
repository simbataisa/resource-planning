The complete assistant conversation surface: header, message log, suggestions and prompt input.

Provide the assistant's name, the messages and a handler for sending. Compose it from Message or Bubble, Suggestion and PromptInput.

- **Container**: `surface`, 1px `border`, `radius-md`.
- **Header**: a `primary-black` Avatar with a bot icon, the name in `contenttitle` and a one-line AI disclosure in `subheader` and `ink-muted`.
- **Log**: `space-16` padding, messages `space-12` apart; behaves as MessageScroller.
- **Footer**: the input and a `primary` send IconButton over a 1px `border` rule.

Always say that answers are AI-generated and may be wrong, and offer a route to a person. Never present generated text as financial advice or as a quoted rate.
