A multi-line text input for free-form messages, with a label above and a counter or helper below.

Provide a visible label, an optional placeholder and, where a limit applies, a character counter.

It shares every state with TextField: 1px `ink-muted` border, `radius-md`, `space-12` by `space-16` padding, `focus-ring` outline, 2px `red-dark` border plus a worded message on error, `secondary-light-grey-80` fill when disabled.

Start at 96px tall and let it grow vertically only. Use TextField for anything that fits on one line.
