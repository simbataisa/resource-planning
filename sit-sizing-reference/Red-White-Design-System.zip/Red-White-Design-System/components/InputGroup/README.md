A text input joined to an add-on: a unit, a prefix, an icon or a button.

Provide the input and one or two add-ons, before or after it.

- **Container**: 1px `ink-muted` border, `radius-md`; the `focus-ring` wraps the whole group.
- **Text add-on**: `secondary-light-grey-80` ground, `ink-muted` text, `space-16` side padding.
- **Button add-on**: an outline Button with square corners, divided by a 1px `ink-muted` rule.

Use text add-ons for fixed context such as a currency or a domain, so the person does not type it. The add-on is not a label; the input still needs its own.
