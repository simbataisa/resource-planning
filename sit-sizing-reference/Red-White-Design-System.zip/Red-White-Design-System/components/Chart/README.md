A simple chart for showing a trend or comparison at a glance.

Provide a title, the unit, the data and a one-sentence summary used as the text alternative.

- **Container**: `surface`, 1px `border`, `radius-md`, `space-24` padding.
- **Bars**: `primary-black`, with `primary` for the one bar being highlighted; top corners `radius-sm`.
- **Values**: printed above each bar in `subnote` at weight 600. **Axis labels**: `subheader` in `ink-muted`.
- **Baseline**: a 1px `primary-black` rule; no gridlines.
- **Further series**: `primary-gold`, then `secondary-grey-60`, which differ in lightness as well as hue.

Label values directly so color is never the only key. Use at most four series. The figures in the preview are placeholders.
