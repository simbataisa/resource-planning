The full-width opening banner: one message, one primary action, one image.

Provide an optional eyebrow, a headline of at most six words, one supporting line, a single primary Button and an image or flat color composition.

- **Ground**: `primary-ivory` behind the copy, or `surface` where the page already uses tints.
- **Eyebrow**: `wtypecaptionsmall` in `red-dark`.
- **Headline**: `text-hero` (40px/60px, weight 300) in `ink`; use `display` on wide desktop layouts.
- **Supporting line**: `subtitle` in `ink`.
- **Media**: fills the other half, flush to the edge. A flat `primary-red` field is the fallback when there is no photograph.

Padding is `space-48`. Keep copy off the red field: white text under 24px on `primary-red` is below 4.5:1. Below `bp-md`, stack media above copy.
