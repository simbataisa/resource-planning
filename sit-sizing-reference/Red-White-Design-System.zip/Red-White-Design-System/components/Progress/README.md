A thin bar that shows how much of a task is complete.

Provide a label, the current value from 0 to 100 and a text readout of the value.

- **Track**: 8px tall, fully rounded, `secondary-light-grey-100`.
- **Fill**: `primary` while in progress; `primary-black` with the word "Hoàn tất" when complete.
- **Label and readout**: `subnote`; label at weight 600 in `ink`, readout in `ink-muted`.

The readout always states the value in words or digits, so the bar is never the only signal. For a flow with named steps, use Stepper.
