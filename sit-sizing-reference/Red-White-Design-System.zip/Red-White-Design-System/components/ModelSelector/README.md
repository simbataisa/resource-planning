A dropdown for choosing which assistant model or mode answers.

Provide the options, each with a name, a one-line description of the trade-off and an icon, plus the current choice.

- **Trigger**: a small outline Button showing the current choice and a chevron.
- **List**: as DropdownMenu, 300px wide.
- **Option**: name in `contenttitle`, description in `subnote` and `ink-muted`.
- **Selected**: `secondary-light-grey-80` ground with a `primary` check mark.

Describe options by what they are good for, not by version numbers. Place it in the PromptInput toolbar. The choice applies to the next message, not to answers already given.
