A blocking dialog that asks the person to confirm or cancel one consequential action.

Provide a title phrased as the question, one or two sentences on the consequence, a cancel action and a confirm action labelled with the verb ("Xóa", not "OK").

- **Scrim**: `overlay`. **Panel**: `surface`, `radius-md`, `shadow-float`, `space-24` padding, at most 440px wide.
- **Title**: `heading3`. **Body**: `default` in `ink-muted`.
- **Actions**: right-aligned outline Button then primary Button.

There is no close icon and clicking the scrim does not dismiss it: the person must choose. Focus starts on the cancel action. For dialogs that hold a form or can be dismissed freely, use Dialog.
