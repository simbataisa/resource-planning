A field that opens a Calendar in a Popover to choose a date.

Provide a label, the selected date and any limits on the range. Dates are written day/month/year.

- **Field**: as TextField, with a 20px calendar icon inset `space-16` from the right.
- **Popover**: holds a Calendar, offset `space-8` below the field.

Selecting a day closes the popover and writes the date into the field. Let people type a date as well as pick one. For dates far in the past, such as a birth date, use three Selects for day, month and year instead.
