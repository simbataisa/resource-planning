The wrapper that lays out a Label, one control and its helper or error text as a unit.

Provide the label, the control (TextField, Select, Textarea, Combobox and so on) and optional description or error text.

- **Stack**: label, control, message, with `space-8` between them.
- **Description**: `subnote` in `ink-muted`.
- **Error**: `subnote` at weight 600 in `red-dark`, starting with "Lỗi:", and a 2px `red-dark` border on the control.

The message is tied to the control so it is read out with it. Stack Fields with `space-24` between them. Show an error after the person leaves the field, not while they type.
