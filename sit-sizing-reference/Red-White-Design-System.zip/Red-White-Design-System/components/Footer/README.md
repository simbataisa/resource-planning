The black closing band: name, link columns and a legal line.

Provide the name in plain type, two to four link columns with a heading each, and the legal text.

- **Ground**: `primary-black`, with `space-48` padding.
- **Column headings**: `wtypecaptionsmall` in `secondary-gold`.
- **Links**: `default` in `primary-white`, underlined on hover; the focus ring is white here.
- **Supporting and legal text**: `subnote` in `secondary-mid-grey-80` (11.6:1 on black), above a 1px `cta-secondary` rule.

No red in the footer; the page's red belongs to its primary action. Below `bp-md`, stack the columns.
