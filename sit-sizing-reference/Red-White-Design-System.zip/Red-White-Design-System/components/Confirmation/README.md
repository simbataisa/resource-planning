A request for permission, shown before the assistant takes an action on the person's behalf.

Provide a sentence naming the action, the exact details it will use, and handlers to allow or decline.

- **Card**: `surface`, a 1px `primary-black` border so it stands apart from ordinary messages, `radius-md`, `space-16` padding.
- **Title**: `contenttitle` with a tool icon.
- **Details**: a two-column list in `subnote`, labels in `ink-muted` and values at weight 600.
- **Actions**: a small primary Button to allow and a small outline Button to decline.

Show every value the action will use; never summarize an amount or a recipient. After a choice, replace the buttons with the outcome in words. Approval here does not replace the bank's own authentication.
