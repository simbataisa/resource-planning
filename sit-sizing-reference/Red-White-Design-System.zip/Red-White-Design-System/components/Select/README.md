A dropdown for choosing one option from a short list.

Provide a visible label and four or more options; the first option is the default or a neutral prompt.

It matches TextField: 1px `ink-muted` border, `radius-md`, `space-12` by `space-16` padding, text in `default`, with a 16px `primary-black` chevron at the right. Focus shows the `focus-ring` outline; disabled uses `secondary-light-grey-80` fill and `secondary-mid-grey-80` border.

For two or three options, use Radio so every choice is visible. The open list uses the platform's native menu.
