A month grid for picking a date.

Provide the visible month, the selected date and any dates that cannot be chosen. Weeks start on Monday, labelled T2 to CN.

- **Container**: `surface`, 1px `border`, `radius-md`, `space-16` padding, 320px wide.
- **Day**: 40px target, `subnote`; `secondary-light-grey-80` on hover.
- **Today**: a 1px `primary-black` outline at weight 600.
- **Selected**: `primary` fill with an `on-primary` number at weight 600.
- **Unavailable**: `ink-muted` and not focusable.

Arrow keys move by day and week; the month buttons are ghost IconButtons. Use it inside DatePicker, or inline when the date is the main choice on the screen.
