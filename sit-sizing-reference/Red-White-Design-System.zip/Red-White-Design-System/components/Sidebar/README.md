The vertical navigation rail for application screens.

Provide the name, navigation items with an icon and label, optional group headings and an account row at the bottom. Mark the current page.

- **Rail**: `surface`, 264px wide, 1px `border` rule on the inner edge, `space-16` padding.
- **Item**: `default` in `ink`, `space-8` by `space-12` padding, `radius-sm`; `secondary-light-grey-80` on hover.
- **Current item**: `secondary-light-grey-80` ground, weight 600 and a `primary` icon.
- **Group heading**: `table-header` in `ink-muted`.

Keep to one level, with at most eight items. Below `bp-lg`, collapse to icons with Tooltips, or move the rail into a Sheet.
