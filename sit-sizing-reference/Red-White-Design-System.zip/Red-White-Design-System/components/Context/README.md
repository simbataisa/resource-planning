A meter showing how much of the assistant's working memory the conversation has used.

Provide the share used and, optionally, a breakdown by what is using it.

- **Card**: `surface`, 1px `border`, `radius-md`, `space-16` padding.
- **Header**: "Ngữ cảnh" in `contenttitle` and the percentage in `subnote` and `ink-muted`.
- **Bar**: 8px, fully rounded, on `secondary-light-grey-100`; segments in `primary-black`, `primary` and `primary-gold`, which differ in lightness.
- **Legend**: `subnote` rows with a swatch, a name and a percentage.

Every segment is also listed as a number, so the colors are only a key. Near the limit, add a caution Alert suggesting a new conversation.
