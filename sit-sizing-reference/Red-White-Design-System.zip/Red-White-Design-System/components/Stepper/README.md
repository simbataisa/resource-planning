A numbered row that shows progress through a multi-step flow such as opening an account.

Provide three to five steps, each with a short label, and which step is current.

- **Done**: `primary-black` dot with a white check; the connector after it is `primary`.
- **Current**: `red-dark` dot with a white number (7.9:1), label in `ink` at weight 600.
- **Upcoming**: `surface` dot with a 1px `ink-muted` border and number; connector in `secondary-light-grey-100`.

Dots are 32px; labels use `subnote`. Each state differs by icon, number and weight, not color alone. Below `bp-md`, show "Bước 2 / 4" with the current label instead of the full row.
