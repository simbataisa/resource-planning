A 24px circle for choosing exactly one option from a small set.

Provide two to five options, each with a label, inside a group that has its own name. Preselect the most common option where one exists.

- **Unselected**: `surface` fill, 1px `ink-muted` border.
- **Selected**: 2px `primary` ring with a 12px `primary` dot.
- **Disabled**: `secondary-light-grey-80` fill, `secondary-mid-grey-80` border, label in `ink-muted`.
- **Focus**: `focus-ring` outline.

Stack options with `space-12` between them. For more than five options, use Select.
