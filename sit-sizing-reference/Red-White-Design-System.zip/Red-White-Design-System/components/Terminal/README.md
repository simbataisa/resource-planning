A dark panel that shows commands the assistant ran and what they printed.

Provide the command and its output as text, and whether it is still running.

- **Panel**: `secondary-grey-100` ground, `radius-md`, text in `primary-white` in the `code` style.
- **Header**: "Dòng lệnh" in `subnote` with a terminal icon over a 1px `cta-secondary` rule.
- **Prompt and summary lines**: `secondary-gold`. **Progress lines**: `secondary-mid-grey-80`.

Output scrolls sideways and is never wrapped. Cap the height and scroll within it, staying at the newest line while running. Errors are marked with the word "Lỗi", not only a color. It is read-only.
