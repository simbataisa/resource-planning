A panel that slides up from the bottom edge, for short tasks on small screens.

Provide a title, a short body and one or two full-width actions.

- **Scrim**: `overlay`. **Panel**: `surface`, top corners `radius-md`, `shadow-float`, `space-24` side padding.
- **Handle**: a 48 by 4px `ink-muted` bar centered at the top, showing it can be dragged down.
- **Title**: `heading3`. **Body**: `default` in `ink-muted`.
- **Actions**: stacked full-width Buttons, primary first, `space-12` apart.

Close on drag down, scrim tap or Escape. Use it in place of Dialog below `bp-md`; on desktop prefer Dialog or Sheet. Keep content short enough not to scroll.
