A flexible row for one object: media, a title with a supporting line, and a value or action at the end.

Provide the title and any of: leading media (icon tile or Avatar), a supporting line, and trailing content such as an amount, a check mark or a small Button.

- **Row**: `surface`, 1px `border`, `radius-md`, `space-12` by `space-16` padding, parts `space-12` apart.
- **Title**: `contenttitle`. **Supporting line**: `subnote` in `ink-muted`.
- **Selected**: a 2px `primary-black` border and a check mark.

Stack rows with `space-8` between them. When rows only navigate, use List, which draws them as one ruled group.
