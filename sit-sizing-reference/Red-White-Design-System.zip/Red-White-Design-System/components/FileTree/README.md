An indented tree of folders and files the assistant can read or has produced.

Provide the hierarchy, which folders are open and which file is selected.

- **Container**: `surface`, 1px `border`, `radius-md`, `space-8` padding.
- **Row**: `subnote` with a 16px folder or file icon, `space-4` by `space-8` padding, `radius-sm`; `secondary-light-grey-80` on hover.
- **Selected**: `secondary-light-grey-80` ground at weight 600.
- **Nesting**: each level indents by `space-20`.

Arrow keys move through rows and open or close folders. Folders and files differ by icon as well as position. Show file names exactly, extension included.
