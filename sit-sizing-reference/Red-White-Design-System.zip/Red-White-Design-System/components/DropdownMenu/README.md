A list of actions that opens from a button.

Provide a trigger and two to eight items, each with a label and an optional icon and shortcut. Group related items with a separator.

- **Panel**: `surface`, 1px `border`, `radius-md`, `shadow-float`, `space-8` padding.
- **Item**: `default` in `ink`, `space-8` by `space-12` padding, `radius-sm`; `secondary-light-grey-80` ground on hover and keyboard focus.
- **Shortcut**: `subheader` in `ink-muted`, right-aligned.
- **Destructive item**: `red-dark` at weight 600, placed last after a separator.

Arrow keys move between items, Enter activates, Escape closes. For choosing a value use Select or Combobox; menus are for actions.
