The scrolling region that holds a conversation and keeps the newest message in view.

Provide the list of Messages or Bubbles. Give the region a name; it is announced as a log.

- **Region**: fixed height, `space-16` padding, messages `space-8` apart, slim scrollbar as ScrollArea.
- **Jump button**: a small outline Button reading "Tin nhắn mới" with a down arrow, centered `space-12` above the bottom edge, with `shadow-float`.

Stay pinned to the bottom while new messages arrive. If the person has scrolled up, do not move them: show the jump button instead and remove it once they return to the bottom.
