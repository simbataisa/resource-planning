A text input that filters a list of options as the person types, for choosing one value from a long list.

Provide a label, the options and the selected value. Use it when there are more than about ten options.

- **Input**: as TextField.
- **List**: `surface` panel with 1px `border`, `radius-md` and `shadow-float`, offset `space-8` below the input.
- **Option**: `default`; `secondary-light-grey-80` on hover and when active.
- **Selected option**: weight 600 with a `primary` check mark at the right.

Arrow keys move through the list, Enter selects, Escape closes. Show "Không tìm thấy" when nothing matches. For short lists use Select or Radio.
