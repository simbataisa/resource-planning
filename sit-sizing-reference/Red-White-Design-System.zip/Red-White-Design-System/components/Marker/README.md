A highlight on a run of text, to pick out a key figure or a search match.

Provide the text to mark. Mark a few words, never a whole paragraph.

- **Highlight**: `secondary-gold` ground with `ink` text (14.9:1) and `radius-sm`, for key figures and terms.
- **Match**: weight 600 with a 2px `primary` underline, for search terms in results.

The text stays `ink` in both, so marking never lowers contrast. Use at most one highlight per paragraph; when everything is marked, nothing stands out.
