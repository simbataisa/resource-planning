A 48 by 28px toggle for a setting that takes effect immediately.

Provide a label on the left that names the setting, and show the state in words ("Bật" or "Tắt") beside the switch so it never relies on color alone.

- **Off**: `ink-muted` track, `primary-white` thumb at the left.
- **On**: `primary` track, thumb at the right.
- **Focus**: `focus-ring` outline around the track.

The track is fully rounded (half its height). Use Checkbox in forms that are submitted later.
