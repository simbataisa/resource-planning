A card where the assistant sets out what it intends to do, for the person to approve before anything happens.

Provide a title for the goal, the ordered steps and the actions to approve or edit.

- **Card**: `surface`, 1px `border`, `radius-md`, `space-24` padding.
- **Eyebrow**: "Kế hoạch" in `table-header` and `ink-muted`. **Title**: `heading3`.
- **Steps**: numbered outline dots with `default` text, `space-12` apart.
- **Actions**: a small primary Button to run it and a small outline Button to edit.

State amounts, dates and accounts in the steps exactly. Nothing runs until the person approves, and each step that moves money still needs its own Confirmation.
