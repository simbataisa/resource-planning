A timeline of the steps inside one request or run, showing when each started and how long it took.

Provide the spans in order, each with a name, start offset, duration, nesting depth and status.

- **Container**: `surface`, 1px `border`, `radius-md`, `space-16` padding.
- **Row**: 32px tall with three columns: name, timeline and duration.
- **Name**: `subnote`, indented `space-16` per level; the root is weight 600.
- **Bar**: `primary-black` on a `secondary-light-grey-80` track. **Failed span**: a `red-dark` bar with the word "Lỗi" in its name.
- **Duration**: `subheader` in `ink-muted`, right-aligned with tabular figures.

Durations are always printed, so bar length is never the only measure. Let a row expand to show its attributes. Preview timings are placeholders.
