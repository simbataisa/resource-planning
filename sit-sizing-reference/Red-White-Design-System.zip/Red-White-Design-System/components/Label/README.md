The text that names a form control.

Provide the label text and link it to its control. Say whether the field is required or optional in words.

- **Label**: 14px/21px at weight 600 in `ink`.
- **Required**: a `red-dark` asterisk together with the word "bắt buộc" on first use in a form.
- **Optional**: "(không bắt buộc)" in `ink-muted` at regular weight.
- **Disabled**: `ink-muted`.

Write labels as nouns in sentence case with no colon. Every control has a label; a placeholder is never a substitute.
