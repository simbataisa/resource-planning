A small numbered marker in a sentence that links a claim to its source.

Provide the source number and its title; the number matches the entry in Sources.

- **Marker**: a 20px `primary-black` square with `radius-sm` and a `primary-white` number at 12px and weight 600, set just after the claim.
- **Preview**: on hover or focus, a HoverCard with the title in `subnote` at weight 600 and the origin in `subheader` and `ink-muted`.

Put the marker after the clause it supports, before the full stop. Its accessible name includes the word "Nguồn" and the number. Cite every figure, rate and rule the assistant states.
