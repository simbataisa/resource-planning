A box that holds its width-to-height ratio while its width changes, so media never shifts the layout as it loads.

Provide the ratio and the media to place inside; the media fills the box and is cropped to cover.

Use 16:9 for hero and banner images, 4:3 for card media and 1:1 for avatars and product tiles. The box takes `radius-md` and shows `primary-ivory` until the media loads.

Do not stretch images to fit; crop them. Keep one ratio per row of cards.
