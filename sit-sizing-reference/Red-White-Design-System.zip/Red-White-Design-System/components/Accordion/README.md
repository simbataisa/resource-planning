A stack of questions that open in place to show their answers, for FAQs and long terms.

Provide a list of title and body pairs. Titles are full questions or noun phrases; bodies are one or two short paragraphs.

- **Row**: 1px `border` rule above and below, `space-16` vertical padding.
- **Title**: `contenttitle` (16px, weight 600) in `ink`.
- **Marker**: a plus that becomes a minus, in `red-dark`, at the right.
- **Body**: `default` in `ink-muted`.
- **Focus**: `focus-ring` outline on the title row.

Any number of rows may be open at once. Do not nest accordions, and do not hide content people need to compare side by side.
