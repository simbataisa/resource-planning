A horizontally scrolling row of cards or banners, shown a few at a time.

Provide the slides and a name for the carousel. Each slide is a Card or an image with a title.

- **Track**: slides `space-24` apart, snapping to the start edge; the next slide peeks in to show there is more.
- **Slide media**: `radius-md`.
- **Controls**: CarouselControls below the track: `ink-muted` dots, a `primary` pill for the current slide, and outline IconButtons.

It scrolls by touch, trackpad, arrow buttons and keyboard. Do not auto-advance content people need to read. If every slide matters, use a grid instead; carousels hide what is off screen.
