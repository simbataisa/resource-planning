A one-question-at-a-time form for short surveys and product finders.

Provide the ordered questions, the answer options for each and what happens on completion.

- **Card**: `surface`, 1px `border`, `radius-md`, `space-24` padding, at most 480px wide.
- **Progress**: "Câu 2 / 5" in `subnote` with a Progress bar.
- **Question**: `heading3`.
- **Option**: a full-width row with a 1px `ink-muted` border and `radius-md`; when chosen it gains a 2px `primary-black` border and weight 600.
- **Footer**: outline "Quay lại" at the left, primary "Tiếp theo" at the right.

Ask one thing per step, allow going back without losing answers, and keep to seven questions or fewer.
