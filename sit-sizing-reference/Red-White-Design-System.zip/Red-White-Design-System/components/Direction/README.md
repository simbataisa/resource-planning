A wrapper that sets the reading direction for everything inside it.

Provide the direction, left-to-right or right-to-left, once at the root of the page or of an embedded region.

Components follow it automatically when they are built with logical spacing (start and end, not left and right). Directional icons such as chevrons and arrows mirror in right-to-left; icons without direction, numbers and the logo do not.

The system's source language is Vietnamese, which reads left to right. Use this only for content in right-to-left languages, and test every component in it before release.
