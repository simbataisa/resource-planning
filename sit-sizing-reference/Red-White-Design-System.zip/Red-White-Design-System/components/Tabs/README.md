An underlined tab row that switches between sibling views in place.

Provide two to five short labels and one panel per tab. Keep labels to one or two words.

- **Selected**: `ink` label at weight 600 with a 2px `primary` underline. The weight change marks the state as well as the color.
- **Unselected**: `ink-muted` label at weight 400; `ink` on hover.
- **Row**: 1px `border` rule under the tabs, `space-32` between tabs, each tab 40px tall.
- **Focus**: 2px solid `primary-black` outline.

Labels use `default`. Do not use tabs for page navigation; use the Header for that. On widths below `bp-md`, let the row scroll sideways rather than wrap.
