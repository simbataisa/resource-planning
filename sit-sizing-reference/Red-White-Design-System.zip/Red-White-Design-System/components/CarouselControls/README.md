Dots and arrows for stepping through a carousel of banners or cards.

Provide the number of slides, the current index and handlers for previous, next and jump-to-slide.

- **Dot**: 8px `ink-muted` circle.
- **Current dot**: a 24 by 8px `primary` pill. It differs in shape as well as color.
- **Arrows**: outline IconButtons at either end.

Gaps are `space-8` between dots and `space-24` to the arrows. Do not auto-advance faster than every five seconds, and pause on hover or focus. Show at most seven dots; beyond that, use a "3 / 12" counter.
