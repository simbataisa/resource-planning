A collapsible checklist that tracks the sub-tasks of one piece of work the assistant is doing.

Provide the task title and its items, each with a label and a status: done, running or waiting.

- **Container**: `surface`, 1px `border`, `radius-md`, `space-16` padding.
- **Header**: title in `contenttitle`, a count such as "2 / 4" in `subnote` and `ink-muted`, and a chevron.
- **Done**: `primary-black` dot with a check. **Running**: `red-dark` dot, label at weight 600 with an ellipsis. **Waiting**: outlined dot, label in `ink-muted`.

Keep it open while work is running and collapse it when done. A failed item shows a `red-dark` cross and the word "Lỗi" with a retry action.
