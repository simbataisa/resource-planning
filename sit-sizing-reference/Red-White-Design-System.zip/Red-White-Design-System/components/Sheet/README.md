A panel that slides in from the side of the screen for filters, details or secondary navigation.

Provide a title, the content and, where the content changes something, one primary action pinned at the bottom.

- **Scrim**: `overlay`. **Panel**: `surface`, full height, 320px wide, square corners, `shadow-float`, `space-24` padding.
- **Title**: `heading3`. **Close**: a ghost IconButton at the top right.
- **Footer action**: a full-width primary Button.

It enters from the right by default; use the left for navigation. Close on Escape or scrim click and return focus to the trigger. Below `bp-md`, let it take the full width or use Drawer.
