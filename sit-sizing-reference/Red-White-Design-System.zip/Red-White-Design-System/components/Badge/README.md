A small count or dot that draws attention to something new.

Provide the number, or nothing for a dot. Include the count in the accessible name of the control it sits on.

- **Count**: 24px tall pill, 12px at weight 600; `on-primary` on `primary` for unread items (4.72:1).
- **Neutral count**: `primary-white` on `primary-black`. **Outline**: `ink` with a 1px `primary-black` outline.
- **Dot**: 12px `primary` circle with a 2px `surface` ring.
- **On a control**: offset `space-8` beyond the top-right corner.

Cap counts at "99+". For category and status labels with words, use Tag. Use at most one red badge per region.
