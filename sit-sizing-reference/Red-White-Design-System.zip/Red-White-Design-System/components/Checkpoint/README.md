A marker in a conversation that records a state the person can return to.

Provide the time or a short name for the checkpoint and a restore handler.

- **Line**: a dashed 1px `ink-muted` rule across the thread, with the label in the middle.
- **Label**: `subnote` in `ink-muted` with a clock icon.
- **Restore**: a text button in `red-dark` at weight 600 with an undo icon.

Restoring discards what came after, so confirm it with an AlertDialog. Say plainly what a restore does and does not undo: it can roll back drafts and settings in the conversation, never a completed payment.
