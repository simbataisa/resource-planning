A segmented control for choosing one option from a short set, such as a time range or a view.

Provide two to five short labels and the selected value.

- **Track**: `secondary-light-grey-80`, `radius-md`, `space-4` padding.
- **Segment**: `default` in `ink-muted`, `space-8` by `space-16` padding.
- **Selected segment**: `surface` fill with a 1px `primary-black` outline, `ink` label at weight 600.

Selection changes the view immediately. It behaves as a radio group: arrow keys move the selection. For more than five options, use Select.
