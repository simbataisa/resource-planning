A brief message that appears at the edge of the screen to confirm an action, then leaves.

Provide one short sentence and, optionally, a single action such as undo or retry.

- **Default**: `secondary-grey-100` ground, `primary-white` text, `radius-md`, `shadow-float`.
- **Success**: `surface` panel with a `color-button-added` icon and a "Thành công" title.
- **Error**: `surface` panel with a `red-dark` icon and a "Lỗi" title in `red-dark`; it stays until dismissed.
- **Action**: an underlined text button at weight 600.

Show toasts at the bottom on mobile and the top right on desktop, one at a time, for about five seconds; pause on hover or focus. Anything the person must act on belongs in an Alert or AlertDialog.
