White is the ground and red is the voice. Build every screen on `surface`, set copy in `ink`, and spend `primary` on the one thing the person should do next.

## Color

- Use `surface` (white) for the page, header, cards and inputs. Use `surface-muted` for alternate section bands only.
- Use `primary` (red) for the primary button, active indicators and key highlights. One primary action per view.
- Put `on-primary` on `primary` fills (4.72:1). `primary` is `primary-red-accessible`, a slightly deeper red than the source `primary-red`; never put white text under 24px on `primary-red` itself (4.39:1).
- For red text below 24px, use `red-dark`, never `primary-red`.
- Use `primary-hover` for hover and pressed states of red fills.
- Set headings and body in `ink`; secondary text in `ink-muted`. Do not use `secondary-mid-grey-100` for readable text: it is 2.55:1 on white.
- Use `border` or `secondary-light-grey-100` for 1px dividers and outlines.
- Reserve `primary-gold` and `secondary-gold` for premium and priority contexts, as fills and rules. Reserve `primary-navy-blue`, `primary-sky-grey` and `primary-ivory` for occasional panels.
- Status: `green` and `bg-button-added` with `color-button-added` text for success. Always add a word or icon; never signal by color alone.

## Typography

- One reading family: `sans`. A second family, `mono`, is for code and machine output only. The source stack leads with SF Pro Display, which is licensed to Apple platforms and is not bundled here; other platforms fall back to Helvetica Neue, Helvetica, then Arial.
- Headlines are light: `display`, `text-hero`, `heading1`, `heading2` and `heading4` at weight 300. Only `heading3` and `stats` are semibold.
- Body is `default` (16px/24px). Use `contentbody` for long articles and `subnote` for captions.
- Button labels use `contenttitle` (16px, weight 600).
- Use `wtypecaptionsmall` for spaced eyebrow labels; keep them short.

## Spacing and layout

- Spacing steps are literal pixels: `space-8` and `space-12` inside components, `space-24` for card padding and gutters, `space-64` between sections (`space-48` on mobile).
- The main layout switch is `bp-md` (767px). Design mobile first, then widen.
- Page side margins in the source are fluid, about 4.4% of the viewport width.

## Shape and elevation

- Round with `radius-md` (8px) by default: buttons, cards, images. Use `radius-sm` for chips.
- Prefer borders over shadows. Use `shadow-card` for raised cards, `shadow-float` for dropdowns, `shadow-pop` for tooltips.

## Components

- Mark "selected" the same way everywhere: `ink` text at weight 600 with a 2px `primary` underline (Tabs, Header, Pagination).
- Every interactive element shows the `focus-ring` outline: 2px solid, offset 2px; white on dark grounds.
- Controls are `control-height` (56px) or `control-height-sm` (40px) tall; icons are `icon-size` with a 2px stroke.
- Form controls take a 1px `ink-muted` border, not `border`: the light greys fall below 3:1 on white.
- Errors use `red-dark` with a word such as "Lỗi"; keep `primary` for actions so the two reds are never confused.
- One red fill per region: the primary Button in a section, the login block in the Header, the current dot in a carousel.
- Overlays (Dialog, AlertDialog, Sheet, Drawer) sit on `overlay`; floating panels (Popover, DropdownMenu, Combobox, HoverCard) use 1px `border`, `radius-md` and `shadow-float`.
- Selected rows and options in menus and lists take a `secondary-light-grey-80` ground at weight 600, with a `primary` check where a value is chosen.
- Status is shown with a symbol and a word everywhere: `primary-black` for done, `red-dark` for active or failed, `color-button-added` for success.
- Code and machine output use the `mono` family in the `code` style; dark panels use `secondary-grey-100` with `primary-white` text and a white focus ring.
- AI components always disclose that content is AI-generated, cite sources with InlineCitation and Sources, and ask through Confirmation before acting.

## Content

- Write short, verb-led calls to action in sentence case, such as "Xem thêm" and "Đăng nhập".
- No emoji. Icons are outlined line icons (the source uses Material Symbols Outlined).

## Logo and imagery

- A logo file is stored in the Other asset group. Use it exactly as supplied, on `surface`, with clear space of at least `space-24` around it; never redraw, recolor or stretch it. Where it cannot be used, set the name in plain type.
