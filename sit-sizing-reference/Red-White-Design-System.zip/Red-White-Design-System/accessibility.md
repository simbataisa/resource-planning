# Accessibility

Use these pairs as checked. Ratios are WCAG 2 contrast, text on ground.

| Text | Ground | Ratio | Use |
| --- | --- | --- | --- |
| `ink` | `surface` | 21:1 | Any text |
| `ink` | `surface-muted` | 19.4:1 | Any text |
| `ink-muted` | `surface` | 6.2:1 | Any text |
| `ink-muted` | `surface-muted` | 5.7:1 | Any text |
| `red-dark` | `surface` | 7.9:1 | Any text |
| `primary-white` | `red-dark` | 7.9:1 | Any text |
| `primary-white` | `cta-secondary` | 10.4:1 | Any text |
| `primary-black` | `primary-gold` | 11.1:1 | Any text |
| `color-button-added` | `bg-button-added` | 5.7:1 | Any text |
| `on-primary` | `primary` | 4.72:1 | Any text |
| `primary-red` | `surface` | 4.39:1 | Text 24px and up, icons, rules only |
| `primary-white` | `primary-red` | 4.39:1 | Source pair; text 24px and up, icons only |
| `cyan-blue` | `surface` | 3.65:1 | Icons and rings only |
| `secondary-mid-grey-100` | `surface` | 2.55:1 | Disabled or decorative only |

## Rules

- Never signal a state by color alone. Selected items change weight and gain an underline; errors, success and cautions carry a word and an icon; the current carousel dot changes shape.
- Give every control a visible label or an `aria-label`. Placeholders are not labels.
- Keep touch targets at least 40px (`control-height-sm`).
- Show the `focus-ring` on keyboard focus for every interactive element; do not remove outlines.
- Borders that define a control (inputs, checkboxes, radios) use `ink-muted` or darker so they reach 3:1 on white.
- Success green and brand red differ in lightness as well as hue (`color-button-added` on its tint against `red-dark` on white), and each comes with its own word.
